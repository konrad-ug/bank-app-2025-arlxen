import pytest
import requests


class TestAPI:
    url = "http://127.0.0.1:5000/api"

    @pytest.fixture(autouse=True, scope="function")
    def set_up(self):
        payload = {
            "first_name": "Anita",
            "last_name": "Fisher",
            "pesel": "33344455566"
        }
        response = requests.post(f"{self.url}/accounts", json=payload)
        assert response.status_code == 200

        yield

        all_accounts = requests.get(f"{self.url}/accounts").json()
        for account in all_accounts:
            response_delete = requests.delete(f"{self.url}/accounts/{account['pesel']}")

    def test_create_account(self):
        url = f"{self.url}/accounts"
        payload = {
            "first_name": "John",
            "last_name": "Smith",
            "pesel": "33344455566"
        }

        response = requests.post(url, json=payload)
        assert response.status_code == 200

    def test_create_account_2(self):
        url = f"{self.url}/accounts"
        payload = {
            "first_name": "Peter",
            "last_name": "Johnson",
            "pesel": "11234567890"
        }

        response = requests.post(url, json=payload)
        assert response.status_code == 200
        print(response.json())

    def test_delete_account(self):
        url = f"{self.url}/accounts"
        payload = {
            "first_name": "Mark",
            "last_name": "Johnson",
            "pesel": "11234567890"
        }

        response = requests.post(url, json=payload)
        url_del = f"{self.url}/accounts/33344455566"
        response_2 = requests.delete(url_del)
        assert response_2.status_code == 200

    def test_update_account(self):
        url = f"{self.url}/accounts"
        payload = {
            "first_name": "Ralph",
            "last_name": "Wilson",
            "pesel": "11234567890"
        }

        response = requests.post(url, json=payload)
        payload_update = {
        "first_name": "Peter",
        "last_name": "Smith"
        }

        url_update = f"{self.url}/accounts/33344455566"
        response_2 = requests.patch(url_update, json=payload)
        assert response_2.status_code == 200

    def test_search_account(self):
        url = f"{self.url}/accounts"
        payload = {
            "first_name": "Ralph",
            "last_name": "Wilson",
            "pesel": "11234567890"
        }
        response = requests.post(url, json=payload)
        url_search = f"{self.url}/accounts/33344455566"
        response_2 = requests.get(url_search)
        assert response_2.status_code == 200

    def test_search_nonexisting_account(self):
        url = f"{self.url}/accounts"
        payload = {
            "first_name": "Ralph",
            "last_name": "Wilson",
            "pesel": "11234567890"
        }

        response = requests.post(url, json=payload)
        url_search = f"{self.url}/accounts/33344455566"
        response_2 = requests.get(url_search)
        assert response_2.status_code == 404

    def test_adding_two_accounts_with_the_same_pesel(self):
        url = f"{self.url}/accounts"
        payload = {
            "first_name": "Ralph",
            "last_name": "Wilson",
            "pesel": "11234567890"
        }
        response_1 = requests.post(url, json=payload)

        url = f"{self.url}/accounts"
        payload = {
            "first_name": "Kevin",
            "last_name": "Smith",
            "pesel": "11234567890"
        }
        response_2 = requests.post(url, json=payload)
        assert response_2.status_code == 409
