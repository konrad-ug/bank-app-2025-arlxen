import pytest
from src.company_account import CompanyAccount
from unittest.mock import patch, Mock

class Test_company_account():

    def test_firm_account_incorrect_NIP(self):
        account = CompanyAccount("Test Bank", "55555555555555")
        assert account.nip == "Invalid"

    @patch('src.company_account.CompanyAccount.is_nip_correct', return_value=True)
    def test_Company_accout_Correct_NIP(self, mock_is_nip_correct):
        account = CompanyAccount("Test Bank", "1234567890")
        assert account.nip == "1234567890"

    @patch('src.company_account.requests.get')
    def test_correct_nip(self, mock_get):
        mock_get.return_value.status_code = 200
        mock_get.return_value.json.return_value = {
            "result": {
                "subject": {
                    "statusVat": "Czynny",
                    "nip": "2345678901",
                    "name": "Test Company"
                }
            }
        }

        account = CompanyAccount("Test Bank", "2345678901")
        
        assert account.is_nip_correct("2345678901")

    @patch('src.company_account.requests.get')
    def test_incorrect_nip(self, mock_get):
        mock_get.return_value.status_code = 200
        mock_get.return_value.json.return_value = {
            "result": {
                "subject": {
                    "statusVat": "Zwolniony"
                }
            }
        }

        with pytest.raises(ValueError, match="Company not registered!"):
                CompanyAccount("Test Bank", "3456789012")
