from requests import patch
from src.company_account import CompanyAccount
from unittest.mock import patch, Mock
from src.smtp.smtp import SMTPClient

class TestCompanyEmail:

    @patch('src.smtp.smtp.SMTPClient.send', return_value=True)
    @patch('src.company_account.requests.get')
    def testing_sending_company_account_email(self, mock_get, mock_send):
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {'result': {'subject': {'statusVat': 'Czynny'}}}
        mock_get.return_value = mock_response
        
        self.account = CompanyAccount("Test Company", "4567890123")
        email = "test@company.com"
        self.account.history = [100, 200, -50, 300, -100]

        result = self.account.send_history_via_email(email)

        assert result

        mock_send.assert_called_once()
        subject = mock_send.call_args[0][0]
        text = mock_send.call_args[0][1]

    @patch('src.smtp.smtp.SMTPClient.send', return_value=False)
    @patch('src.company_account.requests.get')
    def testing_sending_company_account_email_fail(self, mock_get, mock_send):
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {'result': {'subject': {'statusVat': 'Czynny'}}}
        mock_get.return_value = mock_response
        
        self.account = CompanyAccount("Test Company", "4567890123")
        email = "test@company.com"
        self.account.history = [100, 200, -50, 300, -100]

        result = self.account.send_history_via_email(email)

        assert not result
        mock_send.assert_called_once()
        subject = mock_send.call_args[0][0]
        text = mock_send.call_args[0][1]      
