from src.personal_account import PersonalAccount
from src.company_account import CompanyAccount
from src.account_registry import AccountRegistry
import pytest

class TestAccount:

    def test_account_creation(self):
        account = PersonalAccount("John", "Doe", "45678901234")
        assert account.first_name == "John"
        assert account.last_name == "Doe"
        assert account.balance == 0
        assert account.pesel == "45678901234"

    @pytest.mark.parametrize(
        "pesel",
        [
            "12345",
            "999888777666555444333",
            None,
        ],
        ids=[
            "pesel_too_short",
            "pesel_too_long",
            "pesel_non_digit",
        ]
    )
    def test_wrong_pesel(self, pesel):
        account = PersonalAccount("Jane", "Doe", pesel)
        assert account.pesel == "Invalid"

    @pytest.mark.parametrize(
        "pesel, promo, expected_balance",
        [
            ("11234567890", "PROM_YTS", 50),
            ("11234567890", "INVALID_CODE", 0),
            ("11234567890", "PROM_WYZS", 0),
            ("11234567890", "PROM_wz", 0),
            ("59200812340", "PROM_XYZ", 0),
            ("05212312340",   "PROM_XYZ", 50),
        ],
        ids=[
            "correct_promo_code",
            "weird_promo_code",
            "promo_too_long",
            "promo_too_short",
            "old_person_no_bonus",
            "young_person_bonus",
        ]
    )
    def test_promo_codes(self, pesel, promo, expected_balance):
        account = PersonalAccount("Jane", "Doe", pesel, promo)
        assert account.balance == expected_balance

class Test_AccountRegistry:
    @pytest.fixture(autouse=True)
    def setup_account(self):
        self.All_accounts = AccountRegistry()
        self.people = [PersonalAccount("John", "Smith","11234567890"), PersonalAccount("Jane", "Johnson", "23456789012"), PersonalAccount("Robert", "Wilson", "34567890123")]
        for i in self.people:
            self.All_accounts.add_account(i) 

    def test_adding_accounts(self):
        actual = []
        for acc in self.All_accounts.every_account():
            actual.append([acc.first_name, acc.last_name, acc.pesel])

        expected = [
            ["John", "Smith", "11234567890"], 
            ["Jane", "Johnson", "23456789012"], 
            ["Robert", "Wilson", "34567890123"]
        ]
        assert actual == expected

    def test_count_accounts(self):
        assert self.All_accounts.number_of_accounts() == 3

    def test_search_pesel_correct(self):
        assert self.All_accounts.search_pesel("11234567890") == ["John", "Smith", "11234567890", 0]
    
    def test_search_pesel_incorrect(self):
        assert not self.All_accounts.search_pesel("99887766554")
