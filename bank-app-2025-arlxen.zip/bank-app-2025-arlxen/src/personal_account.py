from src.account import Account
from src.smtp.smtp import SMTPClient
from datetime import datetime

class PersonalAccount(Account):
    def __init__(self, first_name, last_name, pesel, promo_code = None):
        self.first_name = first_name
        self.last_name = last_name
        self.balance = 50 if self.is_promo_code(promo_code, pesel) else 0
        self.pesel = pesel if self.is_pesel_valid(pesel) else "Invalid"
        self.history = []

    def is_pesel_valid(self, pesel):
        if isinstance(pesel, str) and len(pesel) == 11:
            return True
        else:
            return False
    
    def is_promo_code(self, promo_code, pesel):
        if (promo_code != None and promo_code[0:5] == "PROM_" and len(promo_code[5:]) == 3) and ((int(pesel[0:2]) > 60 and int(pesel[2:4]) < 20) or (int(pesel[2:4]) > 20)):
            return True
        else:
            return False
    
    def _has_three_positive_transactions(self):
        if len(self.history) >= 3:
            return all(self.history[i] > 0 for i in [-1, -2, -3])
        return False
        
    def _has_sufficient_transaction_history(self, amount):
        if len(self.history) >= 5:
            last_five_sum = sum(self.history[-5:])
            return last_five_sum > amount
        return False

    def submit_for_loan(self, amount):
        if self._has_three_positive_transactions():
            self.balance += amount
            return True
        elif self._has_sufficient_transaction_history(amount):
            self.balance += amount
            return True
        else:
            return False
    def send_history_via_email(self, email_address) -> bool:

        subject = f"Account Transfer History {datetime.now().strftime('%Y-%m-%d')}"
        text = f"Personal account history: {self.history}"
        
        return SMTPClient.send(subject, text, email_address)
    
    @classmethod
    def from_dict(cls, data):
        """Create PersonalAccount from dictionary (e.g., from MongoDB)"""
        account = cls(data['first_name'], data['last_name'], data['pesel'])
        account.balance = data.get('balance', account.balance)
        account.history = data.get('history', [])
        return account            
