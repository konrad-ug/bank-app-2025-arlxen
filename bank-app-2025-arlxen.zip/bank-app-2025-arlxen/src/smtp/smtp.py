class SMTPClient:
    def send(self, subject: str, text: str, email_address: str) -> bool:
        return False
