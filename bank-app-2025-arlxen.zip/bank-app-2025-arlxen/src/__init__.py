"""Top-level package for the bank app domain models."""

