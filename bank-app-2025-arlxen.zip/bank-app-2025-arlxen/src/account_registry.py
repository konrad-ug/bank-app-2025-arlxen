from src.personal_account import PersonalAccount

class AccountRegistry:
    def __init__(self):
        self.accounts = []

    def add_account(self, account: PersonalAccount):
        if len(self.accounts) == 0 or not self.search_pesel(account.pesel):
            self.accounts.append(account)
            return True
        else:
            return False

    def search_pesel(self, pesel):
        for account in self.accounts:
            if account.pesel == pesel:
                return [account.first_name, account.last_name, account.pesel, account.balance]
        return False

    def every_account(self):
        return self.accounts

    def number_of_accounts(self):
        return len(self.accounts)
    
    def update_account(self, pesel, new_first_name, new_last_name):
        for account in self.accounts:
            if account.pesel == pesel:
                account.first_name = new_first_name
                account.last_name = new_last_name
                return "Account Updated"
        return False

    def delete_account(self, pesel):
        for account in self.accounts:
            if account.pesel == pesel:
                self.accounts.remove(account)
                return "Account deleted"
        return False

    def registry_money(self, pesel, amount, transfer_type):
        for account in self.accounts:
            if account.pesel == pesel:
                if transfer_type == "incoming":
                    account.getting_money(amount)
                    return True
                elif transfer_type == "outgoing" and int(account.balance) >= int(amount):
                    account.outgoing_transfer(amount)
                    return True
                elif transfer_type == "express" and account.balance + 1 >= amount:
                    account.fast_outgoing_transfer(amount)
                    return True
                else:
                    return False
        return False
    
