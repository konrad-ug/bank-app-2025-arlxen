class Account:

    def getting_money(self, amount):
        if isinstance(amount, (int, float)):
            self.balance += amount
            self.history.append(amount)

    def outgoing_transfer(self, amount):
        if amount < self.balance and amount > 0:
            self.balance -= amount
            self.history.append(-amount)

    def fast_outgoing_transfer(self, amount):
        if hasattr(self, "company_name") and self.balance - amount - 5 >= -5:
            self.balance -= amount + 5
            self.history.append(-amount)
            self.history.append(-5)
        elif hasattr(self, "first_name") and self.balance - amount - 1 >= -1:
            self.balance -= amount + 1
            self.history.append(-amount)
            self.history.append(-1)
