# Bank-app

## Author:
name:Olivier

surname:Otta

group:4

## How to start the app
1. Have python and docker installed
2. pip install -r requirements.txt
3. Docker: "docker compose -f mongo.yml up -d"
4. Flask: "python -m flask -app src/app/api.py --debug run"
## How to execute tests
1. Run tests
2. python -m pytest -v tests/
